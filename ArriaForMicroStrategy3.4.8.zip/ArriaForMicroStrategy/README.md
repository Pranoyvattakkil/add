# MicroStrategy

## Dev setup

### .npmrc

Arria Connect SDK used to build Microstrategy BI add-in is distributed via npm registry in Azure DevOps artifacts feed.

To connect to the feed, follow "Connect to feed" / select "npm":

https://dev.azure.com/ArriaNLG/ArriaConnect/_packaging?_a=connect&feed=arria-connect-sdk

e.g.

`.npmrc`

```
registry=https://pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/registry/

always-auth=true
```

`$HOME/.npmrc`

```
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/registry/:username=ArriaNLG
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/registry/:_password="YOUR-BASE64-ENCODED-ACCESS-TOKEN"
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/registry/:email=x
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/:username=ArriaNLG
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/:_password="YOUR-BASE64-ENCODED-ACCESS-TOKEN"
//pkgs.dev.azure.com/ArriaNLG/_packaging/arria-connect-sdk/npm/:email=x
```

### .env

Create `.env` file

`.env`

```
BIIS_HOST=biis-stable....com
BIIS_AUTH=Yml3...Zzdl
COGNITO_END_POINT=https://t....com
COGNITO_SIGNUP_REDIRECT=https://t....com/signup
COGNITO_RESET_REDIRECT=https://t....com/reset
COGNITO_RESET_REDIRECT=https://t....com/reset
ARRIA_CONNECT_DEV_TOKEN=eyJh....D9ms
PLUGIN_NAME=ArriaForMicroStrategy
IN_HOST=in-stable...com
```

Set IN_HOST to the location where the Arria Connect postMessage UI is hosted. This may be the hosted stable/model BI resources environment, or a locally hosted version for development.

Configuring the PLUGIN_NAME allows the loading of multiple versions of the plugin in the same environment. If not set, it will default to `ArriaForMicroStrategy`.

NOTE: do not commit `.env` into the repo

## Developing the add-in

```sh
$ npm install
$ npm run start
```

The add-in is written in Typescript, and is constructed using the [Arria Connect SDK](https://docs.integrations.arria.com/OEMSolutions/ArriaConnect/en/index-en.html) and the [Microstrategy mstr-viz](https://lw.microstrategy.com/msdz/MSDL/GARelease_Current/docs/projects/VisSDK/Content/topics/HTML5/develop_custom_viz_tool.htm) development tool.

Executing `npm run start` will start Nodemon, which monitors the `src-ts/main.ts` file for changes and compiles the output to the `dist/` directory.

The plugin name is configurable in the `.env` file under `PLUGIN_NAME` variable and will default to "ArriaForMicroStrategy" if not provided. This allows deploying multiple builds of the plugin to the same server so that multiple devs or testers can use different versions.

## Building the add-in

```sh
$ npm install
$ npm run build
```

Building the add-in is done in two stages:

1 - Webpack compiles the add-in Typescript files and the Connect SDK from `src-ts/` directory, outputting the result to `src/ArriaForMicroStrategy.js`.

2 - `mstr-viz-build` tool compiles the final add-in package using the contents of the `src` directory as the input. The result is outputted to `dist/ArriaForMicroStrategy`.

**Note:** the file and folder names will change depending on the value provided for the `PLUGIN_NAME` variable in the `.env` file.

## Installing the add-in

### Microstrategy Workstation

Plugins can be added to Worksation in two ways:

Compress the contents of `/dist/yourPluginName` to a zip file, and add it via the Workstation 'Add custom visual' dialog.

Alternatively, copy the contents of `/dist/yourPluginName` to one of the following plugin directories:

**Windows**: `C:\Program Files\MicroStrategy\Workstation\Code\plugins\`

**Mac OSX**: `/Applications/MicroStrategy\ Workstation.app/Contents/Frameworks/OneTierDashboardWindow.framework/Resources/code/plugins`

### Microstrategy Server

Plugins can be added to Microstrategy Server deployments by placing the content of `/dist/yourPluginName` to one of the following directories:

**IIS Plugin location**: `C:\Program Files (x86)\MicroStrategy\Web ASPx\plugins`

**Tomcat Plugin location**: `C:\Program Files (x86)\Common Files\MicroStrategy\Tomcat\apache-tomcat-9.0.39\webapps\MicroStrategy\plugins`

### Microstrategy Library

**Tomcat plugin location**: `C:\Program Files (x86)\Common Files\MicroStrategy\Tomcat\apache-tomcat-9.0.39\webapps\MicroStrategyLibrary\plugins`
